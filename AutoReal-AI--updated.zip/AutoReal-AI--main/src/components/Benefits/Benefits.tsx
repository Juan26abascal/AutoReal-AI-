import React, { useState, useEffect, useRef } from 'react';
import { MessageSquare, Calendar, Inbox, Sparkles, FileText } from 'lucide-react';
import BenefitCard from './BenefitCard';
import ProgressIndicator from './ProgressIndicator';


const benefits = [
  {
    icon: MessageSquare,
    headline: "AI Opportunity Audit",
    description: "We map your workflows, quantify hours at stake and deliver a prioritized roadmap."
  },
  {
    icon: Calendar,
    headline: "Prototype to Production",
    description: "Custom automations and LLM agents built, tested and deployed within weeks."
  },
  {
    icon: Inbox,
    headline: "Single Source of Truth",
    description: "Dashboards and unified inboxes keep data and conversations in one place."
  },
  {
    icon: Sparkles,
    headline: "Upskill & Support",
    description: "Live training sessions and on‑call optimisation so adoption sticks."
  },
  {
    icon: FileText,
    headline: "Process Documentation",
    description: "Clear SOPs ensure your team can iterate long after launch."
  }
];


const Benefits = () => {
  const [activeIndex, setActiveIndex] = useState(0);
  const sectionRef = useRef<HTMLDivElement>(null);
  const cardRefs = useRef<(HTMLDivElement | null)[]>([]);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const index = cardRefs.current.findIndex(ref => ref === entry.target);
            if (index !== -1) {
              setActiveIndex(index);
            }
          }
        });
      },
      {
        root: null,
        rootMargin: '-30% 0px -30% 0px', // Increased margins for later triggering
        threshold: 0.5 // Increased threshold for more precise triggering
      }
    );

    cardRefs.current.forEach(ref => {
      if (ref) observer.observe(ref);
    });

    return () => observer.disconnect();
  }, []);

  return (
    <section id="features" ref={sectionRef} className="py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
            Effortlessly Manage Leads, Streamline Operations, and{' '}
            <span className="bg-gradient-to-r from-cyan-400 to-blue-600 bg-clip-text text-transparent">
              Close More Deals
            </span>
          </h2>
        </div>

        <div className="flex gap-12 max-w-6xl mx-auto">
          <ProgressIndicator totalSteps={benefits.length} activeStep={activeIndex} />
          
          <div className="flex-1 space-y-32"> {/* Increased spacing between cards */}
            {benefits.map((benefit, index) => (
              <div 
                key={index}
                ref={el => cardRefs.current[index] = el}
                className="scroll-mt-64" // Increased scroll margin
              >
                <BenefitCard
                  icon={benefit.icon}
                  headline={benefit.headline}
                  description={benefit.description}
                  isActive={index === activeIndex}
                />
              </div>
            ))}
          </div>
        </div>

        <div className="text-center mt-16">
          <button className="bg-gradient-to-r from-cyan-400 to-blue-600 text-white px-8 py-4 rounded-full font-medium hover:shadow-lg transition-all text-lg">
            Transform My Real Estate Business
          </button>
        </div>
      </div>
    </section>
  );
};

export default Benefits;